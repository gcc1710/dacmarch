class Pat9
{
	
   /* public static void main (String args[])
	{
		int  i=65;
		
		for(i=65; i<=69; i++)
		{
			
			for(int k=68; k>=i; k--);
			{
				System.out.print("  ");
			}
			for(int j=65; j<=i; j++)
			{
				System.out.print((char)j+" ");
			}	
		System.out.println();
		}
	}*/
	public static void main(String args[])
	{
		int i=65;
		for(i=65; i<=69; i++)
		{
			for(int k=68; k>=i; k--)
			{
				System.out.print(" ");
			}
			for(int j=65; j<=i; j++)
			{
				System.out.print((char)j+" ");
			}
		System.out.println();
		}
	}
}	
	/*public static void main (String args[])
	{
	for (int i = 0; i < 10; i++)
	{
    if (i == 5)
	{
        break;
    }
    System.out.println(i);
	
	}
	}*/
