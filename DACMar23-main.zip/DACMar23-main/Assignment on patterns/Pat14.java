class Pat14
{
	public static void main(String args[])
	{
		int k , l;
		//for(i=1; i<=5; i++)
		for(k=5; k>=1; k--)
		{
			for(l=1; l<=k; l++)
			{
				System.out.print(l+" ");
			}
			System.out.println();
		}
	}
}	