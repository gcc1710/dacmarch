class HollowHP
{
	public static void main(String args[])
	{
		for(int i=1; i<=6; i++)
		{
			for(int j=6; j>=i; j--)
			{
				if(i==1 || j==1 || (i+j==7))
				{	
				System.out.print("* ");
				}
				else
					System.out.print(" ");
			} 
			System.out.println();
		}
	}
}