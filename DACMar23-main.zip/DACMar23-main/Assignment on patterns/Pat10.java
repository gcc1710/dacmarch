class Pat10
{
   public static void main(String args[])
   
   {
       int i=69;
	   for(i=69; i>=65; i--)
	   {
          for(int j=69; j>=69; j--)
		  {
		     System.out.print((char)j+" ");
			}
			
	      for(int k=68; k>=65; k--)
		  {
		     System.out.print(" ");
			}
			 System.out.println();
		}
	}
}	
   
