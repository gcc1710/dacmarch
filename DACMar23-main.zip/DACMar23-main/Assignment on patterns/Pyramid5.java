class Pyramid5
{
	public static void main(String args[])
	{
		int i , j;
		
		for(i=1; i<=9; i++)
		{
			for(int k=8; k>=i-1; k--)
			{
				System.out.print("  ");
			}
			for(j=9-i+1; j<=9; j++)
			{
				System.out.print(j+" ");
			}
		
		
		
			for(j=8; j>9-i; j--)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}	
		
		
	}
}	