class Pyramid4
{
	public static void main(String args[])
	{
		int i , j;
		int p=1;
		for(i=1; i<=9; i++)
		{
			for(int k=8; k>=i; k--)
			{
				System.out.print("  ");
			}
			for(j=1; j<=i; j++)
			{
				System.out.print(j+" ");
			}
		
		
		
			for(j=i-1; j>=1; j--)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}	
		
		
	}
}	