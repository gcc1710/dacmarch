//convert boolean value to string
class Q_6
{
    public static void main(String args[])
    {
    boolean b = true;
    String s = Boolean.toString(b);
    System.out.println("Boolean instance is :"+s);
    }
}